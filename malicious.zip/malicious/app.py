from flask import Flask, render_template, request
import pickle
import numpy as np

model1 = pickle.load(open(r'C:\Users\nivet\Downloads\malicious\model\malicious.pkl','rb'))  

app = Flask(__name__)  # initializing Flask app


@app.route("/",methods=['GET'])
def hello():
    return render_template('index.html')


@app.route("/predict", methods=['POST'])
def predict():
    if request.method == 'POST': 

        
        d1 = request.form['url']
        
      
        
        
        arr = np.array([[d1]])
        print([d1])
        pred1 = model1.predict(arr)
        print(pred1)

    return render_template('result.html',prediction_text1=pred1)
    
if __name__ == '__main__':
    app.run(debug=True)